#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <string>
#include <iostream>

#include "optimizer.h"
#include "ir.h"

using namespace std;

void optimize_ir(IRInst *head)
{
    return;
}

int constant_folding(IRInst *head)
{
    return 0;
}

int dead_code_elimination(IRInst *head)
{
    return 0;
}